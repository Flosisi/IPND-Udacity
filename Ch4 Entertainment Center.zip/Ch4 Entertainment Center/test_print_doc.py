import media

print (media.Video.__doc__)
print (media.Video.__init__.__doc__)
print (media.Video.showtrailer.__doc__)

print (media.Movie.__doc__)
print (media.Movie.__init__.__doc__)

print (media.TV_Series.__doc__)
print (media.TV_Series.__init__.__doc__)
